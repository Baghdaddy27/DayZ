#!/bin/bash

CURRENT_DAY=$(date +%u)  # 7 = Sunday

if [ "$CURRENT_DAY" -eq 7 ]; then
    echo "[$(date)] Sunday detected — resetting market files..."

    SOURCE="/home/jordan/Games/DayZ_Server/profiles_takistan/ExpansionMod/Market_Defaults"
    DEST="/home/jordan/Games/DayZ_Server/profiles_takistan/ExpansionMod/Market"

    if [ -d "$SOURCE" ]; then
        cp -rf "$SOURCE"/* "$DEST"/
        echo "[$(date)] Market reset complete."
    else
        echo "[$(date)] WARNING: Source directory not found: $SOURCE"
    fi
else
    echo "[$(date)] Not Sunday — skipping market reset."
fi

sleep 1

cd /home/jordan/Games/DayZ_Server

# Start server
./DayZServer -config=server_takistan.cfg -port=2301 "-mod=@CF;@Dabs Framework;@TakistanPlus;@DayZ-Expansion-Licensed;@DayZ-Expansion-Bundle;@Community-Online-Tools;@Takistan Clothing" "-serverMod=@DayZ-Dynamic-AI-Addon" -BEpath=battleye -profiles=profiles_takistan -dologs -adminlog -netlog -freezecheck

read -p "Done. Press Enter to close..."